<!DOCTYPE html>
<html lang="en">

@include('layouts.head')

<body>
        @yield('content')

    @include('layouts.js')
</body>

</html>